givenString = "psg college of technology"

console.log(`length of the string: ${givenString.length}`)

