clgName = "PSG TECH"

new_name = clgName.replace('TECH','College of Technology');

console.log(new_name)