givenString = "Augxy Moon"
let i = 2;
let j = 6;

console.log(`Substring ${givenString.slice(i,j+1)}`)
