let givenString = "javascript"

let convertedString = givenString.toUpperCase();
console.log(convertedString)

let dconvertedString = convertedString.toLowerCase();
console.log(dconvertedString)
