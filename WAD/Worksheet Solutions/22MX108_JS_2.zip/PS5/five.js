let str_one = "My First Web Project tells"
let str_two="my success"

// let str_three = str_one + " " + str_two
str_three = str_one.concat(" ",str_two);
console.log(str_three)

