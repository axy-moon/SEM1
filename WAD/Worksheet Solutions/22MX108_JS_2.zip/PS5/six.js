/*
String trim()
String charAt()
String split()
String replaceAll()
*/

//substring
let str = "PSG COLLEGE OF TECHNOLOGY"
let subString = str.substring(7)
console.log(subString)

//indexOf
let message = "JavaScript";
let index = message.indexOf("pt");
let startBool = message.startsWith("J")
console.log(index)

//startswith

